/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ab4;

import java.util.HashMap;

/**
 *
 * @author marinbulachi
 */
public class County {
    HashMap<String, Location> locations = new HashMap();

    public HashMap<String, Location> getLocations() {
        return locations;
    }
    
}
