
public interface ProgramPart {

    public int accept(ProgramPartVisitor programPartVisitor);

}
