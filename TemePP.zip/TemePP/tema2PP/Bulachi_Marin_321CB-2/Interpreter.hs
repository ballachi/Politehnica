module Interpreter
  (
    -- * Types
    Prog,
    Asgn,

    -- * Functions
    evalRaw,
    evalAdt,
  ) where

-------------------------------------------------------------------------------
--------------------------------- The Expr ADT  -------------------------------
-------------------------------------------------------------------------------
data Expr = Add Expr Expr
          | Sub Expr Expr
          | Mult Expr Expr
          | Equal Expr Expr
          | Smaller Expr Expr
          | Symbol String
          | Value Int deriving (Show, Read)


-------------------------------------------------------------------------------
---------------------------------- The Prog ADT -------------------------------
-------------------------------------------------------------------------------
data Asgn = Asgn String Expr deriving (Show, Read)

data Prog = Eq Asgn
          | Seq Prog Prog
          | If Expr Prog Prog
          | For Asgn Expr Asgn Prog
          | Assert Expr
          | Return Expr deriving (Show, Read)



evalAdt :: Prog -> Either String Int
evalAdt p = eval (evalProg p [])  

evalRaw :: String -> Either String Int
evalRaw rawProg =
    case parse rawProg of
        Just prog -> evalAdt prog
        Nothing   -> Left "Syntax error"


parse :: String -> Maybe Prog
parse = \_ -> Nothing

--Am creeat un tip in care voi pastra toate variabilele dupa nume si valoare
type Variabilele = [(String, Int)]  

--Valoarea variabilei, se va compara numele cu fiecare String,
--daca na fost gasit intorc eroare 
valoareaVar :: String -> (Variabilele) -> (Either String Int) 
valoareaVar nume [] = Left "Eroare"
valoareaVar nume ((numeV,val) : variabile) = if (nume == numeV) then Right (val) 
    else valoareaVar nume variabile

-- adaug o variabila, si intorc un vector cu toate varibilele
-- parcurg tot vectorul, Si creez un vector nou
-- daca variabila nu exista va fi adaugata la
-- daca exista va fi inlocuita cu variabila noua
addVar :: String -> Int -> Variabilele -> Variabilele 
addVar nume val [] = (nume,val):[]
addVar nume val ((numeV,valV):variabile) = if (numeV == nume) then (nume,val):variabile
    else (numeV, valV) : (addVar nume val variabile) 


-- functia evalProg face evaluarea in functie de ce tip de program este (patterns matching)
evalProg :: Prog ->  Variabilele -> (Variabilele, Either String Int)
-- Eq. Se adauga o variabila sau se schimba valoarea
evalProg (Eq (Asgn nume  expresie ) ) variabile = 
 if( ((evalExpr expresie variabile)) /= Left "Eroare" )
  then (addVar nume (rightInt (evalExpr expresie variabile) ) variabile , Right 0)
  else ([], Left "Eroare") 

-- Seq. Se evalueaza ambele programe apoi se verifica de erori
-- in caz de eroare se returneaza eroarea respectiva 
evalProg (Seq prg1 prg2) variabile = let 
  (variabile2,y) = (evalProg prg1 variabile) 
  (variabile3,y2) = (evalProg prg2 variabile2) 
   in 
   if (y == Left "Assert failed" || y2 == Left "Assert failed") 
      then
         (variabile3, Left "Assert failed")
   
    else if(y == Left "return" || y2 == Left "return")
      then if (y == Left "return" )
        then  (variabile3 , y )
        else
           (variabile3 , y2 )
      else if (y == Left "Eroare" || y2 == Left "Eroare"  )
      then
      (variabile3, Left "Uninitialized variable")
  else (variabile3,y2)

-- Return. In lista de variabile voi avea in dreapta return in stinga variabila returnata
-- Either va fi de tip String "return" , dupa ce returnez return nu se va mai evalua programul 
evalProg (Return expr) variabile = if( ((evalExpr expr variabile)) /= Left "Eroare" )
  then (addVar "return"  (rightInt (evalExpr expr variabile) ) []  , (  Left "return"  ) )
  else (variabile, Left "Eroare") 

-- If. Evaluez expresia daca e adevarata evaluez programul 1
-- Daca este falsa evaluez programul 2
-- In caz de evaluare programul se va testa de erori
evalProg (If expr prog1 prog2) variabile = if ( (evalExpr expr variabile ) == Left "true")
  then if ((right (evalProg prog1 variabile) ) /= Left "Eroare" )
      then (evalProg prog1 variabile)
      else(variabile, Left "Eroare")
  else if ( (evalExpr expr variabile ) == Left "false")
    then if ((right (evalProg prog2 variabile) ) /= Left "Eroare" )
      then (evalProg prog2 variabile)
      else (variabile, Left "Eroare")
  else (variabile, Left "Eroare")

-- Assert. Evaluez expresia daca e adevarata intorc true (Programul va continua executia)
-- Daca este falsa intorc "Assert failed" (Programul se va opri)
evalProg (Assert expr) var = if (evalExpr expr var == Left "true")
    then (var,Left "true")
  else if  (evalExpr expr var == Left "Eroare")
    then (var, Left "Eroare")
  else (var,Left "Assert failed")

-- For. va face initializarea si va apela o functie evalFor in care se va face forul
evalProg (For init expr init2 prog) variabile = 
  let (var ,y ) = (evalProg (Eq init) variabile )
  in if(y == Left "Eroare")
    then (var, y)
  else evalFor expr  (Eq init2) prog var
   
-- evalFor. Se va evalua expresia daca e adevarata 
-- evaluez cele 2 programe(Eq si programul din for)
-- in caz de eroare intorc eroarea
-- daca expresia este falsa intorc variabilele
evalFor :: Expr -> Prog -> Prog ->  Variabilele -> (Variabilele, Either String Int)
evalFor expr  init  prog var = 
  if (evalExpr expr var == Left "true") then
    let (var2,y) = (evalProg prog var)
        (var3,y2) = (evalProg init var2)
    in
    if(y == Left "Assert failed") then 
      (var2, Left "Assert failed")
      else 
        if(y == Left "Eroare") then
          (var2, Left "Eroare")
        else   
          evalFor expr init prog var3
  else (var ,Left "nu conteaza") 

-- eval. Functia intoarce in caz de program corect valoarea returnata
-- in caz de eroare intoarce eroarea
eval :: (Variabilele, Either String Int) -> (Either String Int)
eval (variabile,Left "return") = valoareaVar "return" variabile
eval (variabile,Left "Uninitialized variable") = Left "Uninitialized variable"
eval (variabile,Left "Assert failed") = Left "Assert failed"
eval (variabile,_) = Left "Missing return"

-- intorce elementul drept din Either
rightInt :: Either String Int -> Int
rightInt (Right a) = a

-- intorce elementul drept din Either
right :: (Variabilele, Either String Int) -> (Either String Int)
right (a,b) = b

-- evalExpr. Functia face evaluarea in functie de ce tip de expresie este (patterns matching)
evalExpr :: Expr -> Variabilele -> Either String Int
-- intorc valoarea
evalExpr (Value x) _ = Right x
-- caut variabila si o intorc. In caz de eroare se va returna eroarea.
evalExpr (Symbol x) var = valoareaVar x var 
-- Add. verific de erori
-- Daca nu sunt erori fac adunarea.
evalExpr (Add a b) var = if ((evalExpr a var /= Left "Eroare") 
      && (evalExpr b var /= Left "Eroare")) then
  Right (rightInt (evalExpr a  var) + rightInt (evalExpr b  var))
  else Left "Eroare"

-- Sub. verific de erori
-- Daca nu sunt erori fac scaderea.
evalExpr (Sub a b) var =if ((evalExpr a var /= Left "Eroare") 
      && (evalExpr b var /= Left "Eroare")) then
  Right (rightInt (evalExpr a  var) - rightInt (evalExpr b  var))
  else Left "Eroare"

-- Sub. verific de erori
-- Daca nu sunt erori fac inmultirea.
evalExpr (Mult a b) var =if ((evalExpr a var /= Left "Eroare") 
      && (evalExpr b var /= Left "Eroare")) then
  Right (rightInt (evalExpr a  var) * rightInt (evalExpr b  var))
  else Left "Eroare"

-- Equal. evaluez expresiile si le compar
evalExpr (Equal a b) var = if((evalExpr a var) == (evalExpr b var))
  then Left "true"  else Left "false" 

-- Smaller. evaluez expresiile si le compar
evalExpr (Smaller a b) var = if((evalExpr a var) < (evalExpr b var))
  then Left "true"  else Left "false"



